# Remove PojavLauncher account data
PojavLauncher uses two types of accounts:
- Local accounts
- Microsoft accounts
<br>

If you wish to remove a local account or a Microsoft account from the launcher:<br>
1. Select the account that you wish to remove in the account selector
2. Press the trash bin button
3. All account data stored in the launcher will be removed immediately.
<br>

Your account data is not shared with any third parties (except Microsoft, of course)<br>
If you need to remove all of your Microsoft account data, go to:<br>
https://aka.ms/CloseAccount
