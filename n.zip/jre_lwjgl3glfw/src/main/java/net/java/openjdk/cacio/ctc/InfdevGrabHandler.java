package net.java.openjdk.cacio.ctc;

public class InfdevGrabHandler {
    public static void setMouseReader(ExternalMouseReader reader) {

    }
    public static void setGrabbed(boolean grabbed) {

    }
}
