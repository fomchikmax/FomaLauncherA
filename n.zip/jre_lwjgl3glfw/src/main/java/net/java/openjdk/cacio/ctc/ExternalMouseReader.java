package net.java.openjdk.cacio.ctc;

public interface ExternalMouseReader {
    int getX();
    int getY();
}
