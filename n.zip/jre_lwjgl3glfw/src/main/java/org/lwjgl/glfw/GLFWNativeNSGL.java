package org.lwjgl.glfw;

import org.lwjgl.system.NativeType;

public class GLFWNativeNSGL {
    @NativeType("id")
    public static long glfwGetNSGLContext(@NativeType("GLFWwindow *") long window) {
        throw new UnsupportedOperationException("Not implemented");
    }
}
