package git.artdeell.installer_agent;

import java.awt.*;

public interface ComponentFilter {
    boolean checkComponent(Component component);
}
