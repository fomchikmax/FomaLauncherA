package com.kdt.pickafile;

public interface DialogTitleListener {
    void onChangeDialogTitle(String newTitle);
}
