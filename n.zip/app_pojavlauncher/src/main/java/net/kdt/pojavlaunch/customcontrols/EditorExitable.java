package net.kdt.pojavlaunch.customcontrols;

public interface EditorExitable {
    void exitEditor();
}
