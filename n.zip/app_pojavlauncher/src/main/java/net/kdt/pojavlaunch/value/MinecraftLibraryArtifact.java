package net.kdt.pojavlaunch.value;

import androidx.annotation.Keep;

@Keep
public class MinecraftLibraryArtifact extends MinecraftClientInfo {
	public String path;
}
