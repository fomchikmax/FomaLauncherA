package net.kdt.pojavlaunch;

import androidx.annotation.Keep;

@Keep
public class JAssetInfo
{
	public String hash;
    public int size;
}
