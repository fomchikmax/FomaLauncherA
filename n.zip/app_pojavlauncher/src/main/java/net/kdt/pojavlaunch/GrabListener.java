package net.kdt.pojavlaunch;

public interface GrabListener {
    void onGrabState(boolean isGrabbing);
}
