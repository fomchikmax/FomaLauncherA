package net.kdt.pojavlaunch.value.launcherprofiles;

import androidx.annotation.Keep;

@Keep
public class MinecraftAuthenticationDatabase {
	public String accessToken;
    public String displayName;
	public String username;
    public String uuid;
	// public MinecraftProfile[] profiles;
}
