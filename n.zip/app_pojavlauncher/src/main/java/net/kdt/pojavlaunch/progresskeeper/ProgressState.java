package net.kdt.pojavlaunch.progresskeeper;

public class ProgressState {
    int progress;
    int resid;
    Object[] varArg;
}
