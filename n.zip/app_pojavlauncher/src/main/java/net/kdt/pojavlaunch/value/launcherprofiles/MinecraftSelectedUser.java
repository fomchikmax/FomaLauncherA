package net.kdt.pojavlaunch.value.launcherprofiles;

import androidx.annotation.Keep;

@Keep
public class MinecraftSelectedUser {
	public String account;
	public String profile;
}
