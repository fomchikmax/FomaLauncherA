package net.kdt.pojavlaunch.progresskeeper;

public interface TaskCountListener {
    void onUpdateTaskCount(int taskCount);
}
