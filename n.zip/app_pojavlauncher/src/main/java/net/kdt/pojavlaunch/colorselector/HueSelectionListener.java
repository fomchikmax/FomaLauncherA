package net.kdt.pojavlaunch.colorselector;

public interface HueSelectionListener {
   void onHueSelected(float hue);
}
