package net.kdt.pojavlaunch.customcontrols;

public interface ControlButtonMenuListener {
    void onClickedMenu();
}
