package net.kdt.pojavlaunch.modloaders.modpacks.models;

public class SearchResult {
    public int totalResultCount;
    public ModItem[] results;
}
