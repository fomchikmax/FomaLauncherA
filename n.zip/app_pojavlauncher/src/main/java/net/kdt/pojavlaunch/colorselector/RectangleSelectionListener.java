package net.kdt.pojavlaunch.colorselector;

public interface RectangleSelectionListener {
    void onLuminosityIntensityChanged(float luminosity, float intensity);
}
