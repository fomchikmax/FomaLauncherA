package net.kdt.pojavlaunch.modloaders.modpacks.models;

public abstract class ModSource {
    public int apiSource;
    public boolean isModpack;
}
