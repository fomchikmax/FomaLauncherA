package net.kdt.pojavlaunch.colorselector;

public interface AlphaSelectionListener {
    void onAlphaSelected(int alpha);
}
