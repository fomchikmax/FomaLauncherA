package net.kdt.pojavlaunch.value;

import androidx.annotation.Keep;

@Keep
public class MinecraftClientInfo {
	public String sha1;
	public int size;
	public String url;
}
