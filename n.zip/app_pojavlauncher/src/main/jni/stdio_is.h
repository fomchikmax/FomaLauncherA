//
// Created by maks on 15.01.2025.
//

#ifndef POJAVLAUNCHER_STDIO_IS_H
#define POJAVLAUNCHER_STDIO_IS_H

#include <stdbool.h>

_Noreturn void nominal_exit(int code, bool is_signal);

#endif //POJAVLAUNCHER_STDIO_IS_H
