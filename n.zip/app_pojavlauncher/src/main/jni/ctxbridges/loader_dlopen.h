//
// Created by maks on 26.10.2024.
//

#ifndef POJAVLAUNCHER_LOADER_DLOPEN_H
#define POJAVLAUNCHER_LOADER_DLOPEN_H

void* loader_dlopen(char* primaryName, char* secondaryName, int flags);

#endif //POJAVLAUNCHER_LOADER_DLOPEN_H
